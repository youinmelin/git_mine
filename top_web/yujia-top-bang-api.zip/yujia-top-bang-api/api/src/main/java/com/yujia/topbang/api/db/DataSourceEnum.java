package com.yujia.topbang.api.db;

/**
 * Druid多数据源配置
 *
 * @author caorui
 * @date 2019-01-29
 */
public interface DataSourceEnum {

    /**
     * TBK_SERVICE
     */
    String TOP_BANG = "top_bang";
}
