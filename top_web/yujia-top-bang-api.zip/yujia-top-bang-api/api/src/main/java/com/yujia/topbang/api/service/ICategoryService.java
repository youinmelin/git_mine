package com.yujia.topbang.api.service;

import com.yujia.topbang.api.entity.CategoryDO;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author caorui
 * @since 2020-09-24
 */
public interface ICategoryService extends IService<CategoryDO> {

}
