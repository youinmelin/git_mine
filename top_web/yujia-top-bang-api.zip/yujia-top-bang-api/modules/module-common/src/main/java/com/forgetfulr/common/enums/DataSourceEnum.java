package com.forgetfulr.common.enums;

/**
 * Druid多数据源配置
 *
 * @author caorui
 * @date 2019-01-29
 */
public interface DataSourceEnum {

    /**
     * PUBLIC_PLATOON
     */
    String PUBLIC_PLATOON = "public_platoon";
}
