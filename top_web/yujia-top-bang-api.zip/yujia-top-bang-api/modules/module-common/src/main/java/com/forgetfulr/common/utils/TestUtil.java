package com.forgetfulr.common.utils;

/**
 * 测试
 *
 * @author caorui
 * @date 2020-06-29 19:29
 * Revision History
 * Date      		Programmer       Notes
 * 2020-06-29   	 caorui		     Initial
 */
public class TestUtil {

    public static void test() {
        System.out.println("123");
    }
}
